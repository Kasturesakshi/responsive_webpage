function toggleMenu() {
    const leftMenu = document.getElementById('leftMenu');
    leftMenu.classList.toggle('collapsed');
}

function adjustPageWidth() {
    const width = window.innerWidth;
    if (width <= 600) {
        document.body.style.zoom = '50%';
    } else if (width <= 700) {
        document.body.style.zoom = '75%';
    } else if (width <= 767) {
        document.body.style.zoom = '80%';
    } else if (width <= 1600) {
        document.body.style.zoom = '90%';
    } else {
        document.body.style.zoom = '100%';
    }
}

window.addEventListener('resize', adjustPageWidth);
window.addEventListener('load', adjustPageWidth);
